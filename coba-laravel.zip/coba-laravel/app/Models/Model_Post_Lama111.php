<?php

namespace App\Models;

class Post
{
    private static $blog_posts = [
        [
            "slug" => "judul-pertama",
            "judul" => "Judul Pertama",
            "penulis" => "Penulis Pertama",
            "posting" => "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eaque dolorem id ipsam tempora ratione doloribus, officia ducimus hic recusandae aperiam repellendus? Quaerat fugit placeat velit, molestias amet soluta nemo minus."
        ],
        [
            "slug" => "judul-kedua",
            "judul" => "Judul Kedua",
            "penulis" => "Penulis Kedua",
            "posting" => "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eaque dolorem id ipsam tempora ratione doloribus, officia ducimus hic recusandae aperiam repellendus? Quaerat fugit placeat velit, molestias amet soluta nemo minus."
        ],

    ];

    public static function all()
    {
        return collect(self::$blog_posts);
    }

    public static function find($slug)
    {
        $posts = static::all();
        return $posts->firstWhere('slug', $slug);
    }
}
