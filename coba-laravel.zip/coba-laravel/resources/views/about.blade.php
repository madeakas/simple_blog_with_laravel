@extends('layouts.main')

@section('container')
    <h1>Tentang Saya</h1>
    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Dolore quae doloribus possimus obcaecati placeat eveniet
        excepturi nobis ex magnam quo atque consequuntur aliquam delectus exercitationem iure quis, voluptatibus quisquam.
        Illo voluptate quasi sint odio doloribus! Enim, distinctio exercitationem id quod sapiente magnam velit, explicabo
        eius omnis sit dolor perspiciatis laborum voluptates. Iusto nostrum suscipit accusamus odio atque magnam qui soluta
        eos laudantium quas? Vel nesciunt voluptas, saepe esse explicabo dolor ea obcaecati recusandae dignissimos possimus
        aliquam eius iusto beatae hic at soluta. Expedita in perferendis ea aspernatur laudantium? Eaque libero perferendis
        temporibus voluptatibus sequi est voluptate ipsum distinctio in et!</p>
@endsection
