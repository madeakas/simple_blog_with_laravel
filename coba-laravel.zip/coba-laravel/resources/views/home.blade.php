@extends('layouts.main')

@section('container')
    <h1>Home</h1>
    <p>Lorem ipsum dolor sit amet consectetur, adipisicing elit. Quia, dolor repudiandae nesciunt sint tempora veritatis
        veniam dolores reiciendis architecto. Quis non praesentium doloribus accusantium, labore suscipit voluptatibus
        laboriosam officia voluptates!</p>
@endsection
