<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Category;
use App\Models\Post;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {


        User::create([
            'name' => 'Made Akas',
            'username' => 'madeakas',
            'email' => 'made@gmail.com',
            'password' => bcrypt('password')
        ]);
        // User::create([
        //     'name' => 'Helen',
        //     'email' => 'helen@gmail.com',
        //     'password' => bcrypt('12345')
        // ]);


        User::factory(3)->create();

        Category::create([
            'name' => 'Web Programming',
            'slug' => 'web-programming',
        ]);

        Category::create([
            'name' => 'Web Desain',
            'slug' => 'web-desain',
        ]);

        Category::create([
            'name' => 'Personal',
            'slug' => 'personal',
        ]);

        Post::factory(20)->create();

        // Post::create([
        //     'title' => 'Judul Pertama',
        //     'slug' => 'judul-pertama',
        //     'excerpt' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Vitae, odit! Aperiam mollitia esse labore et illo molestiae consequuntur quaerat consequatur unde ea, iste totam quos',
        //     'body' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Vitae, odit! Aperiam mollitia esse labore et illo molestiae consequuntur quaerat consequatur unde ea, iste totam quos tempora quidem aspernatur. Magni reprehenderit labore unde architecto exercitationem praesentium dolorum quod iusto quo magnam fuga soluta doloribus quasi illum corporis est assumenda, reiciendis consectetur ab dolorem! Eligendi saepe quisquam ipsum molestias maxime tempore quia consectetur! Exercitationem facere earum sunt, cumque magnam omnis nihil nisi? Labore, beatae. Suscipit nisi facere nemo esse neque labore possimus quia, quos sit deleniti? Omnis explicabo pariatur vel maxime consequuntur mollitia neque, impedit laboriosam tempore dolorem tenetur nostrum optio voluptatibus.',
        //     'category_id' => 1,
        //     'user_id' => 1,
        // ]);

        // Post::create([
        //     'title' => 'Judul Kedua',
        //     'slug' => 'judul-kedua',
        //     'excerpt' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Vitae, odit! Aperiam mollitia esse labore et illo molestiae consequuntur quaerat consequatur unde ea, iste totam quos',
        //     'body' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Vitae, odit! Aperiam mollitia esse labore et illo molestiae consequuntur quaerat consequatur unde ea, iste totam quos tempora quidem aspernatur. Magni reprehenderit labore unde architecto exercitationem praesentium dolorum quod iusto quo magnam fuga soluta doloribus quasi illum corporis est assumenda, reiciendis consectetur ab dolorem! Eligendi saepe quisquam ipsum molestias maxime tempore quia consectetur! Exercitationem facere earum sunt, cumque magnam omnis nihil nisi? Labore, beatae. Suscipit nisi facere nemo esse neque labore possimus quia, quos sit deleniti? Omnis explicabo pariatur vel maxime consequuntur mollitia neque, impedit laboriosam tempore dolorem tenetur nostrum optio voluptatibus.',
        //     'category_id' => 1,
        //     'user_id' => 1,
        // ]);

        // Post::create([
        //     'title' => 'Judul Ketiga',
        //     'slug' => 'judul-ketiga',
        //     'excerpt' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Vitae, odit! Aperiam mollitia esse labore et illo molestiae consequuntur quaerat consequatur unde ea, iste totam quos',
        //     'body' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Vitae, odit! Aperiam mollitia esse labore et illo molestiae consequuntur quaerat consequatur unde ea, iste totam quos tempora quidem aspernatur. Magni reprehenderit labore unde architecto exercitationem praesentium dolorum quod iusto quo magnam fuga soluta doloribus quasi illum corporis est assumenda, reiciendis consectetur ab dolorem! Eligendi saepe quisquam ipsum molestias maxime tempore quia consectetur! Exercitationem facere earum sunt, cumque magnam omnis nihil nisi? Labore, beatae. Suscipit nisi facere nemo esse neque labore possimus quia, quos sit deleniti? Omnis explicabo pariatur vel maxime consequuntur mollitia neque, impedit laboriosam tempore dolorem tenetur nostrum optio voluptatibus.',
        //     'category_id' => 2,
        //     'user_id' => 1,
        // ]);

        // Post::create([
        //     'title' => 'Judul Keempat',
        //     'slug' => 'judul-keempat',
        //     'excerpt' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Vitae, odit! Aperiam mollitia esse labore et illo molestiae consequuntur quaerat consequatur unde ea, iste totam quos',
        //     'body' => 'Lorem ipsum dolor sit, amet consectetur adipisicing elit. Vitae, odit! Aperiam mollitia esse labore et illo molestiae consequuntur quaerat consequatur unde ea, iste totam quos tempora quidem aspernatur. Magni reprehenderit labore unde architecto exercitationem praesentium dolorum quod iusto quo magnam fuga soluta doloribus quasi illum corporis est assumenda, reiciendis consectetur ab dolorem! Eligendi saepe quisquam ipsum molestias maxime tempore quia consectetur! Exercitationem facere earum sunt, cumque magnam omnis nihil nisi? Labore, beatae. Suscipit nisi facere nemo esse neque labore possimus quia, quos sit deleniti? Omnis explicabo pariatur vel maxime consequuntur mollitia neque, impedit laboriosam tempore dolorem tenetur nostrum optio voluptatibus.',
        //     'category_id' => 2,
        //     'user_id' => 2,
        // ]);
    }
}
